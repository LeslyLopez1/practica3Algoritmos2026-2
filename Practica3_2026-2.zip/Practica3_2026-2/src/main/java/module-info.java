module thedicegame.practica3_20262 {
    requires javafx.controls;
    requires javafx.fxml;

    // Exporta y abre tus subpaquetes reales:
    exports thedicegame.practica3_20262.Controlador;
    exports thedicegame.practica3_20262.Modelo;
    exports thedicegame.practica3_20262.Vista;

    opens thedicegame.practica3_20262.Controlador to javafx.fxml;
    opens thedicegame.practica3_20262.Vista to javafx.fxml;
}