package thedicegame.practica3_20262.Controlador;

import thedicegame.practica3_20262.Modelo.Dado;
import thedicegame.practica3_20262.Modelo.Juego;
import thedicegame.practica3_20262.Vista.Grafica;
import thedicegame.practica3_20262.Vista.TheDiceGame_GUI;
import javafx.application.Application;
import javafx.stage.Stage;

public class Controlador_Main extends Application {

    private Juego juego;
    private TheDiceGame_GUI vista;

    private boolean puedeArrastrar = false;
    private Dado dadoArrastrado = null;
    private int estacionOrigen = 0;

    @Override
    public void start(Stage stage) {
        juego = new Juego();
        vista = new TheDiceGame_GUI(juego);

        //botones juego
        vista.getBtnIniciar().setOnAction(e -> accionIniciar());
        vista.getBtnLanzar().setOnAction(e -> accionLanzar());
        vista.getBtnMover().setOnAction(e -> accionMover());

        //botones graficas
        vista.getBtnActividad().setOnAction(e -> Grafica.actividad(juego));
        vista.getBtnThroughput().setOnAction(e -> Grafica.throughput(juego));
        vista.getBtnEnSistema().setOnAction(e -> Grafica.enSistema(juego));
        vista.getBtnTiempo().setOnAction(e -> Grafica.tiempoEnSistema(juego));

        vista.getTablero().setOnMousePressed(e -> alPresionar(e.getX(), e.getY()));
        vista.getTablero().setOnMouseDragged(e -> alArrastrar(e.getX(), e.getY()));
        vista.getTablero().setOnMouseReleased(e -> alSoltar(e.getX(), e.getY()));

        stage.setTitle("The Dice Game");
        stage.setScene(vista.getEscena());
        stage.setResizable(false);
        stage.show();
    }
    //seccion de botones
    private void accionIniciar() {
        juego.iniciar();
        puedeArrastrar = true;
        dadoArrastrado = null;
        vista.setArrastre(null, 0, 0);
        vista.setBotones(true, false);
        vista.habilitarGraficas();
        vista.setRonda(0);
        vista.dibujarTablero();
    }

    private void accionLanzar() {
        juego.lanzarDados();
        puedeArrastrar = false;
        vista.setBotones(false, true);
        vista.dibujarTablero();
    }

    private void accionMover() {
        juego.moverRecursos();
        int numRonda = juego.getRonda();
        vista.setRonda(numRonda);

        if (numRonda >= 20) {
            puedeArrastrar = false;
            vista.setBotones(false, false);
            vista.dibujarTablero();
            vista.mostrarAlertaFinal();
        } else {
            puedeArrastrar = true;
            vista.setBotones(true, false);
            vista.dibujarTablero();
        }
    }

    private void alPresionar(double x, double y) {
        if (!puedeArrastrar) return;
        int i = vista.estacionEn(x, y);
        if (i == -1) return;
        if (!vista.enZonaDados(i, y)) return;

        Dado d = juego.quitarDado(i + 1);
        if (d != null) {
            dadoArrastrado = d;
            estacionOrigen = i + 1;
            vista.setArrastre(d, x, y);
            vista.dibujarTablero();
        }
    }

    private void alArrastrar(double x, double y) {
        if (dadoArrastrado == null) return;
        vista.setArrastre(dadoArrastrado, x, y);
        vista.dibujarTablero();
    }

    private void alSoltar(double x, double y) {
        if (dadoArrastrado == null) return;
        int i = vista.estacionEn(x, y);
        int destino = estacionOrigen;
        if (i != -1) {
            destino = i + 1;
        }
        juego.ponerDado(destino, dadoArrastrado);
        dadoArrastrado = null;
        vista.setArrastre(null, 0, 0);
        vista.dibujarTablero();
    }

    public static void main(String[] args) {
        launch();
    }
}
