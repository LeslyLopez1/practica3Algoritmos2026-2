package thedicegame.practica3_20262.Vista;

import thedicegame.practica3_20262.Modelo.ColaCircular;
import thedicegame.practica3_20262.Modelo.Estacion;
import thedicegame.practica3_20262.Modelo.Juego;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

public class Grafica {

    private static void lineas(String titulo, String ejeYTexto, ColaCircular<Double> datos) {
        NumberAxis ejeX = new NumberAxis(0, 20, 1);
        ejeX.setLabel("Ronda");
        NumberAxis ejeY = new NumberAxis();
        ejeY.setLabel(ejeYTexto);

        LineChart<Number, Number> grafica = new LineChart<>(ejeX, ejeY);
        grafica.setTitle(titulo);
        grafica.setLegendVisible(false);

        XYChart.Series<Number, Number> serie = new XYChart.Series<>();

        int total = datos.getSize();
        for (int i = 0; i < total; i++) {
            double valor = datos.eliminar();
            serie.getData().add(new XYChart.Data<Number, Number>(i, valor));
            datos.insertar(valor);
        }

        grafica.getData().add(serie);
        abrirVentana(titulo, grafica);
    }

    public static void throughput(Juego juego) {
        lineas("Throughput", "Personas que han salido (acumulado)", juego.getHistSalidos());
    }

    public static void enSistema(Juego juego) {
        lineas("Numero en sistema (trabajo en curso)", "Personas en el sistema", juego.getHistEnSistema());
    }

    public static void tiempoEnSistema(Juego juego) {
        lineas("Tiempo en sistema", "Rondas promedio por persona", juego.getHistTiempo());
    }

    public static void actividad(Juego juego) {
        CategoryAxis ejeX = new CategoryAxis();
        ejeX.setLabel("Estacion");
        NumberAxis ejeY = new NumberAxis();
        ejeY.setLabel("Total en las rondas jugadas");

        BarChart<String, Number> grafica = new BarChart<>(ejeX, ejeY);
        grafica.setTitle("Actividad por estacion");

        XYChart.Series<String, Number> serieCapacidad = new XYChart.Series<>();
        serieCapacidad.setName("Capacidad (suma de dados)");
        XYChart.Series<String, Number> serieProcesado = new XYChart.Series<>();
        serieProcesado.setName("Personas procesadas");

        ColaCircular<Estacion> cola = juego.getEstaciones();
        int total = cola.getSize();
        for (int i = 0; i < total; i++) {
            Estacion est = cola.eliminar();
            String nombre = "E" + est.getId();
            serieCapacidad.getData().add(new XYChart.Data<String, Number>(nombre, est.getTotalCapacidad()));
            serieProcesado.getData().add(new XYChart.Data<String, Number>(nombre, est.getTotalProcesado()));
            cola.insertar(est);
        }

        grafica.getData().add(serieCapacidad);
        grafica.getData().add(serieProcesado);
        abrirVentana("Actividad", grafica);
    }

    private static void abrirVentana(String titulo, javafx.scene.chart.Chart grafica) {
        Stage ventana = new Stage();
        ventana.setTitle(titulo);
        ventana.setScene(new Scene(grafica, 620, 400));
        ventana.show();
    }
}
