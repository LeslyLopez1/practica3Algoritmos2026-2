package thedicegame.practica3_20262.Vista;

import thedicegame.practica3_20262.Modelo.ColaCircular;
import thedicegame.practica3_20262.Modelo.Dado;
import thedicegame.practica3_20262.Modelo.Estacion;
import thedicegame.practica3_20262.Modelo.Juego;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class TheDiceGame_GUI {

    private Juego juego;
    private ColaCircular<Image> imagenesDados;
    private Scene escena;
    private Canvas tableroCanvas;
    private Label ronda;
    private Button btnIniciar, btnLanzar, btnMover;
    private Button btnActividad, btnThroughput, btnEnSistema, btnTiempo;
    private Dado dadoArrastrado = null;
    private double mouseX, mouseY;

    public TheDiceGame_GUI(Juego juego) {
        this.juego = juego;
        cargarDados();

        VBox root = new VBox();
        root.setStyle("-fx-background-color: #c9a97a;");
        Label header = new Label("THE DICE GAME - Version 2");
        header.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
        header.setStyle("-fx-background-color: #8b5e3c; -fx-text-fill: #fff8f0; -fx-padding: 10 0;");
        header.setMaxWidth(Double.MAX_VALUE);
        header.setAlignment(Pos.CENTER);

        HBox contenido = new HBox(8);
        contenido.setPadding(new Insets(8, 8, 8, 8));

        tableroCanvas = new Canvas(720, 500);
        dibujarTableroVacio();

        VBox panelDer = crearPanel();

        contenido.getChildren().addAll(tableroCanvas, panelDer);
        root.getChildren().addAll(header, contenido);

        escena = new Scene(root, 910, 560);
    }

    private void cargarDados() {
        imagenesDados = new ColaCircular<>(6);
        for (int i = 1; i <= 6; i++) {
            imagenesDados.insertar(new Image(getClass().getResourceAsStream("/dados/" + i + ".png")));
        }
    }

    private Image getImagen(int valor) {
        Image buscada = null;
        for (int i = 1; i <= 6; i++) {
            Image img = imagenesDados.eliminar();
            if (i == valor) {
                buscada = img;
            }
            imagenesDados.insertar(img);
        }
        return buscada;
    }

    //panel derecho
    private VBox crearPanel() {
        VBox p = new VBox(8);
        p.setPrefWidth(165);
        p.setAlignment(Pos.TOP_CENTER);

        btnIniciar = boton("Iniciar", "#5a3e28");
        btnLanzar  = boton("Lanzar",  "#7a1a00");
        btnMover   = boton("Mover",   "#2d5a1a");

        btnActividad  = boton("Actividad",  "#3a4a6a");
        btnThroughput = boton("Throughput", "#3a4a6a");
        btnEnSistema  = boton("En sistema", "#3a4a6a");
        btnTiempo     = boton("Tiempo",     "#3a4a6a");

        btnLanzar.setDisable(true);
        btnMover.setDisable(true);
        btnActividad.setDisable(true);
        btnThroughput.setDisable(true);
        btnEnSistema.setDisable(true);
        btnTiempo.setDisable(true);

        Label titRonda = new Label("RONDAS");
        titRonda.setFont(Font.font("Georgia", FontWeight.BOLD, 12));
        titRonda.setStyle("-fx-text-fill: #3b2410;");

        ronda = new Label("0");
        ronda.setFont(Font.font("Georgia", FontWeight.BOLD, 36));
        ronda.setStyle("-fx-text-fill: #5a2800;");

        p.getChildren().addAll(btnIniciar, btnLanzar, btnMover,
                btnActividad, btnThroughput, btnEnSistema, btnTiempo,
                titRonda, ronda);
        return p;
    }

    private Button boton(String texto, String color) {
        Button b = new Button(texto);
        b.setPrefWidth(140);
        b.setStyle("-fx-background-color: " + color + "; -fx-text-fill: white; " +
                "-fx-font-size: 13px; -fx-font-weight: bold; -fx-padding: 8 16; " +
                "-fx-background-radius: 6; -fx-cursor: hand;");
        return b;
    }

    public void setRonda(int numero) {
        ronda.setText(String.valueOf(numero));
    }

    public void setBotones(boolean lanzar, boolean mover) {
        btnLanzar.setDisable(!lanzar);
        btnMover.setDisable(!mover);
    }

    public void habilitarGraficas() {
        btnActividad.setDisable(false);
        btnThroughput.setDisable(false);
        btnEnSistema.setDisable(false);
        btnTiempo.setDisable(false);
    }

    public void setArrastre(Dado dado, double x, double y) {
        dadoArrastrado = dado;
        mouseX = x;
        mouseY = y;
    }

    public void mostrarAlertaFinal() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Fin del juego");
        alert.setHeaderText("20 rondas completadas");
        alert.setContentText(
                "Procesados: " + juego.getSalidaRecursos().getSize() +
                        "\nEn sistema: " + juego.getTotalEnSistema() +
                        "\nTiempo promedio: " + String.format("%.1f", juego.getTiempoPromedio()) + " rondas" +
                        "\n\nRevisa las graficas o presiona Iniciar para otra partida."
        );
        alert.showAndWait();
    }

    private double posX(int i) {
        return 15 + (i % 5) * 140;
    }

    private double posY(int i) {
        if (i < 5) return 30;
        return 265;
    }

    public int estacionEn(double x, double y) {
        for (int i = 0; i < 10; i++) {
            if (x >= posX(i) && x <= posX(i) + 130 && y >= posY(i) && y <= posY(i) + 200) {
                return i;
            }
        }
        return -1;
    }

    public boolean enZonaDados(int i, double y) {
        return y <= posY(i) + 156;
    }

    private void dibujarTableroVacio() {
        GraphicsContext gc = tableroCanvas.getGraphicsContext2D();
        double w = tableroCanvas.getWidth(), h = tableroCanvas.getHeight();
        gc.setFill(Color.web("#e8d5b7"));
        gc.fillRect(0, 0, w, h);
        gc.setFill(Color.web("#9b6a3a"));
        gc.setFont(Font.font("Georgia", 14));
        gc.fillText("Presiona Iniciar para comenzar", 20, 30);
    }

    public void dibujarTablero() {
        GraphicsContext gc = tableroCanvas.getGraphicsContext2D();
        double w = tableroCanvas.getWidth(), h = tableroCanvas.getHeight();

        gc.setFill(Color.web("#e8d5b7"));
        gc.fillRect(0, 0, w, h);

        //10 estaciones
        for (int i = 0; i < 10; i++) {
            Estacion est = juego.buscarEstacion(i + 1);
            dibujarEstacion(gc, est, posX(i), posY(i));
        }

        gc.setFill(Color.web("#7a4a20"));
        gc.setFont(Font.font("Georgia", 12));

        if (dadoArrastrado != null) {
            dibujarDado(gc, dadoArrastrado.getValor(), mouseX - 20, mouseY - 20);
        }

        //barra inferior
        gc.setFill(Color.web("#c4924a"));
        gc.fillRect(0, h - 28, w, 28);
        gc.setFill(Color.web("#3b1a00"));
        gc.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
        gc.fillText("Procesados: " + juego.getSalidaRecursos().getSize()
                        + " / En sistema: " + juego.getTotalEnSistema(),
                14, h - 10);
    }

    private void dibujarEstacion(GraphicsContext gc, Estacion est, double x0, double y0) {
        //rectangulo grande estacion
        gc.setFill(Color.web("#ddc49a"));
        gc.fillRoundRect(x0, y0, 130, 200, 8, 8);
        gc.setStroke(Color.web("#9b6a3a")); gc.setLineWidth(1.2);
        gc.strokeRoundRect(x0, y0, 130, 200, 8, 8);

        //identificador y cantidad de dados
        gc.setFill(Color.web("#6a3a10"));
        gc.setFont(Font.font("Georgia", FontWeight.BOLD, 18));
        gc.fillText("E" + est.getId(), x0 + 4, y0 + 16);

        //dados: se saca cada uno de la cola, se dibuja y se vuelve a meter
        ColaCircular<Dado> dados = est.getDados();
        int totalDados = dados.getSize();
        //si hay muchos dados las filas se juntan para no tapar a las personas
        double pasoFila = 43;
        if (totalDados > 6) {
            pasoFila = 30;
        }
        for (int j = 0; j < totalDados; j++) {
            Dado d = dados.eliminar();
            double dx = x0 + 2 + (j % 3) * 43;     // 3 dados por fila
            double dy = y0 + 22 + (j / 3) * pasoFila;
            dibujarDado(gc, d.getValor(), dx, dy);
            dados.insertar(d);
        }

        int en = est.getCantidadEnCola();
        int limite;
        if (en < 22) {
            limite = en;
        } else {
            limite = 22;
        }

        double r = 4.5;
        for (int j = 0; j < limite; j++) {
            double xc = x0 + 9 + (j % 11) * 11;
            double yc = y0 + 160 + (j / 11) * 12;
            gc.setFill(Color.web("#1e6fd9"));
            gc.fillOval(xc - r, yc - r, r * 2, r * 2);
        }

        //total de personas en cola
        gc.setFill(Color.web("#7a4a20"));
        gc.setFont(Font.font("Georgia", FontWeight.BOLD, 20));
        gc.fillText("En cola: " + en, x0 + 4, y0 + 195);
    }

    private void dibujarDado(GraphicsContext gc, int valor, double x, double y) {
        gc.drawImage(getImagen(valor), x, y, 40, 40);
    }

    public Scene getEscena() { return escena; }
    public Canvas getTablero() { return tableroCanvas; }
    public Button getBtnIniciar() { return btnIniciar; }
    public Button getBtnLanzar() { return btnLanzar; }
    public Button getBtnMover() { return btnMover; }
    public Button getBtnActividad() { return btnActividad; }
    public Button getBtnThroughput() { return btnThroughput; }
    public Button getBtnEnSistema() { return btnEnSistema; }
    public Button getBtnTiempo() { return btnTiempo; }
}
