package thedicegame.practica3_20262.Modelo;

import java.util.Random;

public class Dado {
    private int valor;
    private Random random;

    public Dado() {
        this.random = new Random();
        this.valor = 1;
    }

    public int lanzar() {
        valor = random.nextInt(6) + 1; // 1 a 6
        return valor;
    }

    public int getValor() {
        return valor;
    }
}
