package thedicegame.practica3_20262.Modelo;

public class Juego {
    private int numEstaciones = 10;
    private ColaCircular<Estacion> colaEstaciones;
    private ColaCircular<Recurso> salidaRecursos;
    private ColaCircular<Double> histEnSistema;
    private ColaCircular<Double> histSalidos;
    private ColaCircular<Double> histTiempo;
    private int sumaTiempos;
    private int ronda;

    public void iniciar() {
        colaEstaciones = new ColaCircular<>(numEstaciones);
        salidaRecursos = new ColaCircular<>(2000);
        histEnSistema = new ColaCircular<>(21);
        histSalidos = new ColaCircular<>(21);
        histTiempo = new ColaCircular<>(21);
        sumaTiempos = 0;
        ronda = 0;

        for (int i = 0; i < numEstaciones; i++) {
            Estacion est = new Estacion(i + 1);
            if (i > 0) {
                for (int j = 0; j < 4; j++) {
                    est.agregarRecurso(new Recurso(0));
                }
            }
            colaEstaciones.insertar(est);
        }
        guardarHistorial();
    }

    public void lanzarDados() {
        for (int i = 0; i < numEstaciones; i++) {
            Estacion temp = colaEstaciones.eliminar();
            temp.lanzarDados();
            colaEstaciones.insertar(temp);
        }
    }

    public void moverRecursos() {
        ronda++;
        ColaCircular<Recurso> pasan = new ColaCircular<>(1);

        for (int i = 0; i < numEstaciones; i++) {
            Estacion est = colaEstaciones.eliminar();
            int capacidad = est.getCapacidad();
            ColaCircular<Recurso> salen;

            if (i == 0) {
                salen = new ColaCircular<>(capacidad);
                for (int j = 0; j < capacidad; j++) {
                    salen.insertar(new Recurso(ronda - 1));
                }
                est.sumarProcesados(capacidad);
            } else {
                salen = est.procesarRecursos(capacidad);
                est.recibirRecursos(pasan);
            }

            pasan = salen;
            colaEstaciones.insertar(est);
        }
        while (!pasan.isEmpty()) {
            Recurso r = pasan.eliminar();
            sumaTiempos = sumaTiempos + (ronda - r.getRondaEntrada());
            salidaRecursos.insertar(r);
        }

        guardarHistorial();
    }

    private void guardarHistorial() {
        histEnSistema.insertar((double) getTotalEnSistema());
        histSalidos.insertar((double) salidaRecursos.getSize());
        histTiempo.insertar(getTiempoPromedio());
    }

    public Estacion buscarEstacion(int id) {
        Estacion encontrada = null;
        int total = colaEstaciones.getSize();
        for (int i = 0; i < total; i++) {
            Estacion est = colaEstaciones.eliminar();
            if (est.getId() == id) {
                encontrada = est;
            }
            colaEstaciones.insertar(est);
        }
        return encontrada;
    }

    public Dado quitarDado(int idEstacion) {
        Estacion est = buscarEstacion(idEstacion);
        return est.quitarDado();
    }

    public void ponerDado(int idEstacion, Dado d) {
        Estacion est = buscarEstacion(idEstacion);
        est.agregarDado(d);
    }
    
    public double getTiempoPromedio() {
        if (salidaRecursos.getSize() == 0) {
            return 0;
        }
        return (double) sumaTiempos / salidaRecursos.getSize();
    }

    public int getTotalEnSistema() {
        int total = 0;
        for (int i = 0; i < numEstaciones; i++) {
            Estacion temp = colaEstaciones.eliminar();
            total += temp.getCantidadEnCola();
            colaEstaciones.insertar(temp);
        }
        return total;
    }

    public ColaCircular<Estacion> getEstaciones() {
        return colaEstaciones;
    }

    public ColaCircular<Recurso> getSalidaRecursos() {
        return salidaRecursos;
    }

    public ColaCircular<Double> getHistEnSistema() {
        return histEnSistema;
    }

    public ColaCircular<Double> getHistSalidos() {
        return histSalidos;
    }

    public ColaCircular<Double> getHistTiempo() {
        return histTiempo;
    }

    public int getRonda() {
        return ronda;
    }
}
