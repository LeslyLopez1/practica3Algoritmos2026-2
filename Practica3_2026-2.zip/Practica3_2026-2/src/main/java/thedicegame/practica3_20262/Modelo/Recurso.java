package thedicegame.practica3_20262.Modelo;

public class Recurso {
    private boolean estado;
    private int rondaEntrada;

    public Recurso(int rondaEntrada) {
        this.estado = false;
        this.rondaEntrada = rondaEntrada;
    }
    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getRondaEntrada() {
        return rondaEntrada;
    }

    @Override
    public String toString() {
        return "Recurso{estado=" + (estado ? "procesando" : "esperando") + "}";
    }
}