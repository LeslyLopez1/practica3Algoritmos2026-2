package thedicegame.practica3_20262.Modelo;

public class Estacion {
    //cola de personas esperando en esta estacion
    private ColaCircular<Recurso> cola;
    //cola de dados que tiene esta estacion (se pueden mover a otra estacion)
    private ColaCircular<Dado> dados;
    //identificador para cada estacion
    private int id;

    //cuanto puede procesar en la ronda
    private int capacidad;
    //contadores para la grafica de actividad
    private int totalProcesado;
    private int totalCapacidad;

    public Estacion(int id) {
        this.id = id;
        this.cola = new ColaCircular<>(2000);
        this.dados = new ColaCircular<>(10);
        this.dados.insertar(new Dado());
        this.capacidad = 0;
        this.totalProcesado = 0;
        this.totalCapacidad = 0;
    }

    //lanza todos los dados de la estacion y suma los resultados
    public int lanzarDados() {
        capacidad = 0;
        int total = dados.getSize();
        for (int i = 0; i < total; i++) {
            Dado d = dados.eliminar();
            capacidad = capacidad + d.lanzar();
            dados.insertar(d);
        }
        totalCapacidad = totalCapacidad + capacidad;
        return capacidad;
    }

    public Dado quitarDado() {
        return dados.eliminar();
    }

    public void agregarDado(Dado d) {
        dados.insertar(d);
    }

    public ColaCircular<Recurso> procesarRecursos(int cantidad) {
        ColaCircular<Recurso> procesados = new ColaCircular<>(cantidad);
        int movidos = 0;
        while (movidos < cantidad && !cola.isEmpty()) {
            Recurso r = cola.eliminar();
            procesados.insertar(r);
            movidos++;
        }
        totalProcesado = totalProcesado + movidos;
        return procesados;
    }

    public void recibirRecursos(ColaCircular<Recurso> recursos) {
        while (!recursos.isEmpty()) {
            Recurso r = recursos.eliminar();
            if (r != null) {
                cola.insertar(r);
            }
        }
    }

    public void agregarRecurso(Recurso r) {
        cola.insertar(r);
    }

    public void sumarProcesados(int cantidad) {
        totalProcesado = totalProcesado + cantidad;
    }

    //getters
    public ColaCircular<Dado> getDados() {
        return dados;
    }

    public int getId() {
        return id;
    }

    public int getCantidadEnCola() {
        return cola.getSize();
    }

    public int getCantidadDados() {
        return dados.getSize();
    }

    public int getCapacidad() {
        return capacidad;
    }

    public int getTotalProcesado() {
        return totalProcesado;
    }

    public int getTotalCapacidad() {
        return totalCapacidad;
    }
}
